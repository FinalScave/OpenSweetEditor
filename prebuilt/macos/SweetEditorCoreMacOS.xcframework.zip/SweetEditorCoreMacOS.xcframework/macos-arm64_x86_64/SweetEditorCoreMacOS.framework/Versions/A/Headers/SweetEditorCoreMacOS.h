#pragma once

#include <SweetEditorCoreMacOS/c_api.h>
